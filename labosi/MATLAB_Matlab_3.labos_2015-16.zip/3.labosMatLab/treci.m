syms x;

f = @(x) (4*x^3 - 7*x^2 - 7*x -9)/(4*x^4 -7*x^2 + 3*x -19);

nultockeBrojnika = roots ([4 -7 -7 -9]);
nultockeNazivnika = roots ([4 0 -7 3 -19]);

disp (['Nultocke brojnika: ', num2str(double(nultockeBrojnika.'))]);
disp (['Nultocke nazivnika: ', num2str(double(nultockeNazivnika.'))]);

k=1;

for i = 1:length(nultockeBrojnika) 
    if isreal (nultockeBrojnika(i)) %ako je nultocka realna, zapis u realne nultocke
        realneNultocke(k, 1) = nultockeBrojnika(i);
        disp(
        k=k+1;
    end
end

k=1;

for i = 1:length(nultockeNazivnika)
    if isreal (nultockeNazivnika(i))
        realniPrekidi(k, 1) = nultockeNazivnika(i);
        k=k+1;
    end
end

for i=1:length(realniPrekidi)
    lijeviLimes = limit(f, x, realniPrekidi(i), 'left');
    desniLimes = limit(f, x, realniPrekidi(i), 'right');
    disp(['U tocki: ', num2str(double(realniPrekidi(i)))]);
    disp(['Lijevi limes je: ', num2str(double(lijeviLimes))]);
    disp(['Desni limes je: ', num2str(double(desniLimes))]);
end

%figure
%hold on
%ezplot(f);
%plot(double(realneNultocke), 0, 'go');
%plot(double(realniPrekidi), 0, 'rx');
%title('Funkcija f(x)');
%legend('f(x)', 'nultočke', 'prekidi funkcija'); %legend se čudno ponaša
%grid on;
%hold off;

%derivacija

prvaDerivacija = diff(f, 1, x);
disp('Prva derivacija od f(x) po x je:');
pretty(prvaDerivacija);
prvaDerivacija = simplify(prvaDerivacija);
%plot1=ezplot(prvaDerivacija);
%set(plot1, 'Color', [1 1 0]);

drugaDerivacija = diff(f, 2, x);
disp('Druga derivacija of f(x) po x je:');
pretty (drugaDerivacija);
%plot2=ezplot(drugaDerivacija);
%set(plot2, 'Color', [0 1 1]);
%legend('f(x)', 'nultočke', 'prekidi funkcija', 'derivacija 1', 'derivacija
%2'); %ne radi

stacionarneTocke = solve(prvaDerivacija==0);
k=1;
for i=1:length(stacionarneTocke)
    %disp(stacionarneTocke(i)); %provjera
    if isreal(double(stacionarneTocke(i)))
        realneStacTocke(k, 1) = stacionarneTocke(i);    %prazan skup, ruši program
        disp(realneStacTocke(k));
        k=k+1;
    end
end

min=1;
max=1;

for i = 1:size(realneStacTocke, 1)
    if subs(drugaDerivacija, x, double(realneStacTocke(i))) > 0
        minimum(min, 1) = double(realneStacTocke(i));
        MinVrijednost(min, 1) = double(subs(f, x, minimum(min)));
        disp(['Minimum se postiže: ', num2str(minimum(min)), ' iznosi: ', num2str(MinVrijednost(min))])
        min = min + 1;
    elseif subs(drugaDerivacija, x, double(realneStacTocke(i))) < 0
        maximum(max, 1) = double(realneStacTocke(i));
        MaxVrijednost(max, 1) = double(subs(f, x, maximum(max)));
        disp(['Maximum se postiže: ', num2str(maximum(max)), ' iznosi: ', num2str(MaxVrijednost(max))])
        max = max + 1;
    end
end

%novi plot za derivacije
figure
hold on
ezplot(f);
plot(double(realneNultocke), 0, 'go');
plot(double(realniPrekidi), 0, 'rx');
plot1=ezplot(prvaDerivacija);
set(plot1, 'Color', [1 1 0]);
plot2=ezplot(drugaDerivacija);
set(plot2, 'Color', [0 1 1]);
plot(minimum, MinVrijednost, 'gx');
plot(maximum, MaxVrijednost, 'gx');
title('Funkcija f(x)');
legend('f(x)', 'nultočke', 'prekidi funkcija', 'prva derivacija', 'druga derivacija', 'minimum', 'maximum'); %legend se čudno ponaša
grid on;
hold off;

disp(['Povrsina ispod funkcije na intervalu [-1,1] iznosi ', num2str(double(int(f, x, -1, 1)))])



        
        
        

