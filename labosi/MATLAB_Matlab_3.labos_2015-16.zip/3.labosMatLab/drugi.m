syms alpha theta a d;

T=[cos(theta) -cos(alpha)*sin(theta) sin(alpha)*sin(theta) a*cos(theta);
sin(theta) cos(alpha)*cos(theta) -sin(alpha)*cos(theta) a*sin(theta);
0 sin(alpha) cos(alpha) d;
0 0 0 1];
disp ('Prva matrica:');
disp (T);

syms q1 d1 a1 q2;
Ta=subs(T, {theta, d, a, alpha}, {q1, d1, a1, pi});
disp ('Druga matrica:');
disp (Ta);
Tb=subs(T, {theta, d, a, alpha}, {q2, 0, a1, 0});
disp ('Treca matrica:');
disp (Tb);
disp ('Rezultat:');
Tc=Ta.*Tb;
subs(Tc, {q1, q2, a1, d1}, {pi/2, pi/4, 0.3, 0.5});
disp (Tc);