format LONGG;
syms x f;
f(x) = factorial(x);
syms y;
y=10;
subs(f, x, y);

syms g h;
clear y;
syms y;
g(y)=10^y;
h(y) = ((g(y) + f(y)) / (g(y) - f(y)));
y=15;
disp (double(h(15)));
pretty (h(15));