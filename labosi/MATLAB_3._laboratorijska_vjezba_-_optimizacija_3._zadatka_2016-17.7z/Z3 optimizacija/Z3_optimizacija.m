%Disclaimer - zbog lo�ih performansa fplota, ova m-skripta i Z3_preload
%sadr�e optimiziranu funkcionalnost originalnog Z3 uz krace vrijeme
%izvrsavanja. Da bi Z3_optimizacija zaista radila znatno brze, potrebno je
%pokrenuti Z3_preload prije Z3_optimizacije. Osigurao sam da se to uistinu
%izvrsava ako korisnik ne shvati, ali onda ce prvo pokretanje trajati samo
%neznatno manje od originalnog Z3. Vrijeme izvr�avanja - 0.431s, vrijeme
%izvr�avanja bez inicijalizacije - 12.938s. Sva obja�njenja su u originalnoj
%arhivi na materijalima.

%Autor: Ljac

if(~exist('didPreload', 'var'))         %Ako didPreload logicka varijabla ne postoji, odma se pokrece preload
    Z3_preload;
elseif(~didPreload)                     %Ako postoji ali nije true, onda se ucitava.
    Z3_preload;
end

%-------------a) zadatak---------------------------------------------------

uiwait(msgbox(sprintf('Nultocka brojnika je: %g.\nNultocke nazivnika su %g i %g', nul1, nul2, nul3), 'Nultocke'))

%-------------b) zadatak---------------------------------------------------                     

uiwait(msgbox(sprintf('Vrijednosti u tockama prekida su redom {-Inf, Inf} i {Inf, -Inf}'), 'Vrijednosti u tockama prekida'));

%-------------c) zadatak---------------------------------------------------

figure;
subplot(2, 1, 1);
hold on;
grid on;
set(gca,'ylim',[-4 4]);
xlabel('x');
ylabel('y');
title('Graf funkcije');

p1 = plot(domena, f_x, 'Color', [0.251, 0.878, 0.816], 'LineWidth', 1.5);
p2 = plot(nul1, 0, '*k');
%p3 = plot([n2(1), n2(1), n2(2), n2(2)], [y(1,1), y(1,2), y(2,1), y(2,2)], %'*r');
hold off;

%-------------d) zadatak---------------------------------------------------

disp([sprintf('\nPrva derivacija f(x) je:')]);
pretty(d1f);

disp([sprintf('\nDruga derivacija f(x) je:')]);
pretty(d2f);

subplot(2, 2, 3);
hold on;
grid on;
set(gca,'ylim',[-4 4]);
xlabel('x');
ylabel('y');
title('Prva derivacija');
pd1 = plot(domena, d1f_x, 'm', 'LineWidth', 1.5);

lgdd1 = legend([pd1], 'f(x)^{(I)}');
lgdd1.FontSize = 8;
hold off;

subplot(2, 2, 4);
hold on;
grid on;
set(gca,'ylim',[-4 4]);
xlabel('x');
ylabel('y');
title('Druga derivacija');
pd2 = plot(domena, d2f_x, 'r', 'LineWidth', 1.5);

lgdd2 = legend([pd2], 'f(x)^{(II)}');
lgdd2.FontSize = 8;
hold off;

subplot(2, 1, 1)
hold on;
p4 = plot(MaxMin(1), yMaxMin(1), 'ob');
p5 = plot(MaxMin(2), yMaxMin(2), 'og');

lgd = legend([p1 p2 p4 p5], 'f(x)', 'nultocke', 'globalni minimum', 'globalni maksimum');
lgd.FontSize = 8;
hold off;

%-------------e) zadatak---------------------------------------------------

uiwait(msgbox(sprintf('Povrsina ispod f(x) u intervalu od -1 do 1 je priblizno %f kvadratnih jedinica', integral), 'Povrsina'));