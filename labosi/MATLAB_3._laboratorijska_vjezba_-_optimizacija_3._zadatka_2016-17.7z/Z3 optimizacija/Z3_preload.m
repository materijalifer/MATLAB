%Vrijeme izvr�avanja = 13.486s

%Autor: Ljac

syms x;

f_num = 4*x^3   - 7*x^2 - 7*x - 9;
f_den = 4*x^4   - 7*x^2 + 3*x - 19;

f = f_num/f_den;

domena = linspace(-6, 6, 10000);            %Domena nam je od -6 do 6 radi formatinga
f_x = double(subs(f, x, domena));           %Pretvaram vrijednosti u double. VPA ne koristim jer onda varijable ostaju simbolicke.

%--------------------------------------------------------------------------

assume(x, 'real');

n1 = solve(f_num == 0);
n2 = solve(f_den == 0);

nul1 = double(n1);
nul2 = double(n2(1));
nul3 = double(n2(2));

%--------------------------------------------------------------------------

y = [limit(f, x, n2(1), 'left'), limit(f, x, n2(1), 'right');
     limit(f, x, n2(2), 'left'), limit(f, x, n2(2), 'right')];

%--------------------------------------------------------------------------

d1f = simplify(diff(f, x, 1));
d2f = simplify(diff(d1f, x, 1));

d1f_x = double(subs(d1f, x, domena));
d2f_x = double(subs(d2f, x, domena));

%--------------------------------------------------------------------------

MaxMin = double(solve(d1f == 0, x));
yMaxMin = double(subs(f, x, MaxMin));

%--------------------------------------------------------------------------

integral = int(f, x, -1, 1);                %Kako racunanje integrala isto trosi vrijeme a treba se inicijalizirati samo jednom, razlika od Z3 je sto ce ovdje on biti varijabla, a ne direktno izracunat.

didPreload = true;