%Vecina stvari objasnjena je u Z2.m. Ovdje cu samo objasniti neke stvari
%specificne za funkciju. Napominjem da su boje grafova proizvoljne, meni se
%svi?aju. Mo�ete ih slobodno promijeniti u sto god, nije bitno za zadatak.

function poly_approx(x, crtanje)                    %Kako nemamo povratnu vrijednost, ne trebamo je ni pisati. Sintaksa sada slici programskom jeziku.
y = sin(x);
domain = (max(x) - min(x))/2;
space = abs((min(diff(x)))/10);

f_app = polyfit(x, y, 3);
v = [min(x) - domain: space : max(x) + domain];

fv = polyval(f_app, v);
yv = sin(v);

app_err = yv - fv;

%----Graf------------------------------------------------------------------------------------

if crtanje > 0                                      %U funkciji imamo argument koji odabire hocemo li crtati grafove ili ne. Ako hocemo, slijedi:
    figure;
    subplot(2, 1, 1);
    hold on;
    grid on;
    p1 = plot(x, y, 'xk');                              
    p2 = plot(v, yv, 'Color', [0.251, 0.878, 0.816]);   
    p3 = plot(v, fv, '--m');                            
    lgd = legend([p2 p3 p1], 'f(x)', 'f_{app}(x)', '(x_{i}, f(x_{i})');
    lgd.FontSize = 7;
    xlabel('x');
    ylabel('y');
    hold off;
    
    subplot(2, 1, 2);
    hold on;
    grid on;
    p4 = plot(v, app_err, 'b');
    legend(p4, 'Greska aproksimacije');
    xlabel('x');
    ylabel('f(x) = y(x) - f_{app}(x)');
    hold off;
end

end

