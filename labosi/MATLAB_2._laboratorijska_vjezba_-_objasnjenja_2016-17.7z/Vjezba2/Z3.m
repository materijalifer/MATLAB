function [N] = Z3(Podatak, Operacija)                           %Funkcija ima ulazne argumente Podatak i Operacija. Izlazni argument je N.

global Imenik;                                                  %Zbog nekog razloga svi ti genijalni Mathworksovi inzenjeri prisiljavaju ljude da kazu funkciji da ce koristiti globalne varijable. Ovo ne brise postojecu globalnu varijablu Imenik.
ferr = 'Fatalna gre�ka.';                                       %Nekima je FER fatalna greska. Ovo je samo string od "fatal error", koristim vise puta isti tekst.

if nargin ~= 2                                                  %Ako je broj argumenata razlicit od 2, javlja gresku.
    errordlg('Funkcija prima 2 i samo 2 ulazna argumenta.')     %Prava poruka.
    error(ferr);                                                %Ovo postoji samo zato sto errordlg ne halta izvo?enje koda. Dakle, formalnost.
end
if isa(Podatak, 'char') == 0                                    %Podatak je, vjerovali ili ne, niz charova. String je u matlabu deprecated.
    errordlg('Ulazni podatak nije string.')
    error(ferr);
end

if (Operacija ~= 0 && Operacija ~= 1)                           %Operacija smije biti samo 0 ili 1 za izvrsavanje funkcije.
    errordlg('Ulazna operacija nije valjana.')
    error(ferr);
end


ii = find(strcmp(Imenik, Podatak));                             %Ovo tu ce vratiti indeks 1. stupca u kojem se nalazi Podatak. Ako se Podatak ne na?e, rezultat je prazna 0x1 matrica.

if(Operacija == 0)                                              %Ako brisemo:
    if (isempty(ii) == 1)                                       %Ako Podatak nije na?en, isempty(ii) ce vratiti 1.
        errordlg('Pokusaj brisanja nepostojeceg unosa nije uspio.')
        error(ferr);
    else
        Imenik(ii,:) = [];                                      %Ako je Podatak prona?en, taj red zamjenjuje se praznom matricom, tj. brise se.
    end
else
    if(isempty(ii) == 1)
        Imenik = [Imenik; {Podatak, 1}];                        %Imeniku cemo "nadodati" celiju koja se sastoji od Podatka u provm stupcu, te vrijednosti 1 u drugom. []u ovom slucaju oznacavaju konkatenaciju, a ne matricu.
    else
        Imenik{ii,2} = Imenik{ii,2} + 1;                        %Oznacavanje celije radi se sa {}. Ako Podatak vec postoji, susjednu vrijednost u retku povecavamo za 1.
        msgbox(sprintf('Vi�estrukost tra�enog podatka je %g.', Imenik{ii, 2}), 'Rezultat'); %Radi kao i printf u C-u. povratna vrijednost sprintf-a, me?utim, je string.
end
    
    N = numel(find([Imenik{:,2}]));                             %Krenimo iznutra. Prvo trazimo elemente 2. stupca u imeniku koji nisu == 0. Nakon sto smo ih nasli, s funkcijom numel brojim koliko ih ima. Kako se radi u cijelim brojevima, svi elementi su >= 1, kao sto je trebalo i u zadatku. Sretni smo jer ne koristimo smecarske for-eve i if-ove.
end