%Pro?itajte uputu, predugo je da tu pisem.

x = 3*rand(1, 20);                                                  %Definiram x kao retcani vektor nasumicnih 20 elemenata od -3 do 3. Velicina je proizvoljna, ovako samo lijepo izgleda.
y = sin(x);                                                         %Ovdje moze doci bilo koja funkcija koju cemo kasnije aproksimirati. Defaultna je sin(x)
domain = (max(x) - min(x))/2;                                       %Odmah stavljam pola domene x-a radi optimizacije.
space = abs((min(diff(x)))/10);                                     %Desetina najmanje udaljenosti x-a je udaljenost izme?u susjednih v-ova. Abs jer udaljenost mo�e biti negativna.

f_app = polyfit(x, y, 3);                                           %"function approximation" - polifitom trazim krivulju 3. stupnja koja bi najblize odgovarala y kojem je pridruzen x.
v = [min(x) - domain: space : max(x) + domain];                     %Domena v-a je 2x veca od domene x-a, ali imaju isto srediste - dakle, sa svake strane domene x-a dodamo jos Dx/2, tj. domain.

fv = polyval(f_app, v);                                             %"f-app(v)" - racuna vrijednosti f_app kad mu pridruzimo v-eve.
yv = sin(v);                                                        %y(v) - pridruzuje vektoru yv vrijednosti sin(v). Ovdje ce biti ista funkcija kao i u retku 4 matlab skripte.

app_err = yv - fv;                                                  %approximation error - ovdje racunamo devijaciju aproksimiranog polinoma od prave funkcije. To ne radimo sa y jer Dy je manja od Dv.

%----Graf------------------------------------------------------------------------------------

figure;                                                             %Crtamo prozor u kojem cemo nesto crtati
subplot(2, 1, 1);                                                   %Definiramo podprozor (2 redaka, 1 stupac, nalazimo se u prvom retku trenutno).
hold on;                                                            %Ovime osiguravamo da naredbe crtanja ne brisu prethodan crtez
grid on;                                                            %Crta mrezu
p1 = plot(x, y, 'xk');                                              %Objektu p1 pridruzujemo vrijednosti y(x), njih crtamo kao crne iksice.
p2 = plot(v, yv, 'Color', [0.251, 0.878, 0.816]);                   %Objektu p2 pridruzujemo graf y(v) tirkizne boje.
p3 = plot(v, fv, '--m');                                            %Objektu p3 pridruzujemo graf f_app(v) koji je iscrtkane magenta boje.
lgd = legend([p2 p3 p1], 'f(x)', 'f_{app}(x)', '(x_{i}, f(x_{i})'); %Objektu lgd pridruzujemo legendu objekata redom p2 p3 p1, te im dajemo navedene nazive. x_{y} se ispisuje kao x subskripta ono sto je u viticastim zagradama.
lgd.FontSize = 7;                                                   %Definiramo font objekta legenda. Iz nekog razloga mi ovo nije radilo direktno u funkciji legend.
xlabel('x');                                                        %Definiramo labele za osi, te isklju?ujemo hold u podprozor.
ylabel('y');
hold off;

subplot(2, 1, 2);                                                   %Sad smo u 2. retku naseg podprozora
hold on;                                                            
grid on;
p4 = plot(v, app_err, 'b');                                         %Objektu p4 pridruzujemo graf greske aproksimacije po v-u koji iscrtavamo plavom bojom.
legend(p4, 'Greska aproksimacije');                                 %Legenda za graf greske aproksimacije
xlabel('x');                                                        %Samo labele, nista posebno.
ylabel('f(x) = y(x) - f_{app}(x)');
hold off;
