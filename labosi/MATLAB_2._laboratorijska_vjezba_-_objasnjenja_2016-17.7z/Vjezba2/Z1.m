%Definirati x i y u rasponu [-5, 5] te [2, 4]. Funkcijom mesh ispisati
%funkciju (sin(x))   /   ( (cos(y) + 1.1)  * e^(0.05*(x^2 + y^2) )

x = linspace(-5, 5, 100);                       %Definiraju se linearno raspore?enih 100 elemenata.
y = linspace(2, 4, 100);
[X,Y] = meshgrid(x,y);                          %Rade se vektori X i Y, kombinacije x-a i y-a, kao sazimanje domene u matricu.

znum = sin(X);                                  %Brojnik
zden = (cos(Y) + 1.1).*exp(0.05.*(X.^2+Y.^2));  %Nazivnik
z = znum./zden;                                 %./ dijeli svaki element brojnika za elementom nazivnika istog indeksa

mesh(X, Y, z)                                   %Mesh X i Y (MATRICE, ne originalni vektori) pridru�uje funkciji z.