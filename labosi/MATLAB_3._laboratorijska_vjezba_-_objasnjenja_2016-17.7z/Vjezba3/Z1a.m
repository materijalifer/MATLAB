%Autor: Ljac

syms x y
f = factorial(x);

f = subs(f, x, y);              %Sub y za x
f10 = subs(f, y, 10);           %Racunanje f(10)
g = 10^(y);                     %Kreiranje izraza g(y) = 10^(y)

h = (g+f)/(g-f);                %Kreiranje h(y) = (g(y) + f(y))   /   (g(y) - f(y))
h15 = subs(h, y, 15);           %Uvrstavanje y = 15 u izraz

hfrac = h15                     %MATLAB 2016a je automatski postavljen da symove vraca kao razlomke. Dakle, vracamo samo vrijednost h15.

hdoub = vpa(h15, 11)            %VPA simbolicki izraz evaluira brojevno - bez njega opet bi dobili razlomak. Drugi argument je broj znamenaka na koji se zaokruzuje.