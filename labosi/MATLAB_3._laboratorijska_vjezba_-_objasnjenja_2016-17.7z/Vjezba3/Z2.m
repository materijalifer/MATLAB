%Autor: Ljac

syms tht alp a d;                       %tht -> theta, alp -> alpha

T =[cos(tht),   -cos(alp)*sin(tht),     sin(alp)*sin(tht),  a*cos(tht);
    sin(tht),   cos(alp)*cos(tht),      -sin(alp)*cos(tht), a*sin(tht);
    sym(0),     sin(alp),               cos(alp),           d         ;
    sym(0),     sym(0),                 sym(0),             sym(1)    ]

%-------------a) zadatak---------------------------------------------------

display(T);                             %Prikazuje T u simbolickom obliku

%-------------b) zadatak---------------------------------------------------

syms q_1 q_2 a_1 d_1;                   %Moramo definirati nove simbolicke varijable

T_a = subs(T, tht, q_1);                %Prvo cemo T_a definirati kao supstituirani T
T_a = subs(T_a, alp, pi);               %Nakon tog prvog, svaki sljedeci mijenja nesto u T_a, u suprotnom bi imali 4 razlicita T_a, tj. samo onaj zadnji.
T_a = subs(T_a, a, a_1);
T_a = subs(T_a, d, d_1);

T_b = subs(T, tht, q_2);
T_b = subs(T_b, alp, sym(0));
T_b = subs(T_b, a, a_1);
T_b = subs(T_b, d, sym(0));

%-------------c) zadatak---------------------------------------------------

T_c = T_a*T_b;                          %Matricno mnozenje, da nije ne bi trebalo bas nesto pojednostaviti
T_c = simplify(T_c);

%-------------d) zadatak---------------------------------------------------

T_c_value = subs(T_c, q_1, sym(pi/2));
T_c_value = subs(T_c_value, q_2, sym(pi/4));
T_c_value = subs(T_c_value, a_1, sym(0.3));
T_c_value = subs(T_c_value, d_1, sym(0.5));

vpa(T_c_value)                          %Trazi se numericka vrijednost - bez vpa dobit cemo simbolicke vrijednosti (beskonacno precizne)
