%Autor: Ljac

f = sym(2^(1.5));                               %Definiramo ALGEBARSKI IZRAZ 2 na 1.5-tu. Znaci, ne broj, vec simbolicku varijablu.
pretty(f);                                      %Ovo poljepsava f.

bimono = vpa(abs(single(f) - double(f)), 40);   %Razlika izmedju jednostruke i dvostruke preciznosti na 40 ili manje znamenaka.