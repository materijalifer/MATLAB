%Disclaimer - ne koristim ezplot jer je depreciran, vec fplot - on ima
%sasvim jednaku sintaksu kao i plot, ali ima jednu veliku manu - zbog beskonacne
%preciznosti, strasno je spor - za crtanje grafova zato dajte vremena,
%ovisno o racunalu od 30s do cak 2 min. Na 4-jezgrenoj i5ici i 8GB DDR3
%uz neki Windowsov bloatware trajalo je prosje?no 1:15 minuta. Ako hocete
%da ne traje toliko dugo, komentirajte sve redove sa fplot. Takodjer je
%moguce za svaku funkciju uzeti x kao vektor sto bi bilo daleko brze, ali
%to nije u sklopu vjezbe (jer se ovdje radi o simbolickom paketu).

%Autor: Ljac

syms x;                                                 %Deklariramo simbolicku varijablu x.

f_num = 4*x^3   - 7*x^2 - 7*x - 9;                      %Rasclanjujem funkciju na brojnik i nazivnik.
f_den = 4*x^4   - 7*x^2 + 3*x - 19;

f = f_num/f_den;

%-------------a) zadatak---------------------------------------------------

assume(x, 'real');                                      %Gledamo funkciju u domeni realnih brojeva, pa imaginarna rjesenja ne trebamo.

n1 = solve(f_num == 0);                                 %n1 su nultocke brojnika, n2 su nultocke nazivnika.
n2 = solve(f_den == 0);

nul1 = vpa(n1, 6);                                      %nul1, nul2 i nul3 su nase 3 nultocke prevedene iz simbolickog oblika u numericki oblik.
nul2 = vpa(n2(1), 6);
nul3 = vpa(n2(2), 6);

uiwait(msgbox(sprintf('Nultocka brojnika je: %g.\nNultocke nazivnika su %g i %g', nul1, nul2, nul3), 'Nultocke'))
%uiwait je funkcija koja prije nastavljanja sa kodom ceka da korisnik pritisne ok na skocnom prozoru. Ispisujemo numericke vrijednosti x-a.

%-------------b) zadatak---------------------------------------------------

y = [limit(f, x, n2(1), 'left'), limit(f, x, n2(1), 'right');   %Inicijalizirali smo y koji sadr�i na�e y vrijednosti to?aka prekida. U 1. stupcu su lijevi limesi, a u 2. desni limesi. To zapravo nisu to?ke, ve? funkcija tu divergira.
     limit(f, x, n2(2), 'left'), limit(f, x, n2(2), 'right')];                           

uiwait(msgbox(sprintf('Vrijednosti u tockama prekida su redom {-Inf, Inf} i {Inf, -Inf}'), 'Vrijednosti u tockama prekida'));

%-------------c) zadatak---------------------------------------------------

figure;                                                 %Zapravo cemo imati 3 grafa, ali ce nas f(x) zauzimati cijeli gornji redak
subplot(2, 1, 1);                                       %Zato se pravimo kao da imam 2 retka i 1 stupac, kasnije cemo "prevariti" MATLAB i reci da ima 2 retka i stupca.
hold on;
grid on;
xlabel('x');
ylabel('y');
title('Graf funkcije');

p1 = fplot(f, [-30, 30], 'Color', [0.251, 0.878, 0.816], 'LineWidth', 1.5);         %Opet samo uzeo tirkiznu boju za prvi graf, totalno je svejedno sto vi uzmete
p2 = plot(nul1, 0, '*k');                                                           %Ovdje oznacavam nultocku na grafu, sa zvjezdicom.
%p3 = plot([n2(1), n2(1), n2(2), n2(2)], [y(1,1), y(1,2), y(2,1), y(2,2)], %'*r');  %Kad bi nase tocke prekida bile konacne, onda bi mogli ovo napisati i vidjeti nesto na grafu.
hold off;

%-------------d) zadatak---------------------------------------------------

d1f = simplify(diff(f, x, 1));                              %Prvu derivaciju cemo odma pojednostaviti ako je moguce i tako definirati d1f.
disp([sprintf('\nPrva derivacija f(x) je:')]);
pretty(d1f);                                                %pretty ce nam ispisati uljepsani izraz

d2f = simplify(diff(d1f, x, 1));                            %Deriviranje derivacije je 2. derivacija primitivne funkcije.
disp([sprintf('\nDruga derivacija f(x) je:')]);
pretty(d2f);

subplot(2, 2, 3);                                           %Sad se pravimo kako nas subplot zapravo ima 2x2 celija. Ovo nece poremetiti 1. graf koji je zauzeo 1. redak.
hold on;
grid on;
xlabel('x');
ylabel('y');
title('Prva derivacija');
pd1 = fplot(d1f, [-30, 30], 'm', 'LineWidth', 1.5);

lgdd1 = legend([pd1], 'f(x)^{(I)}');
lgdd1.FontSize = 8;
hold off;

subplot(2, 2, 4);
hold on;
grid on;
xlabel('x');
ylabel('y');
title('Druga derivacija');
pd2 = fplot(d2f, [-30, 30], 'r', 'LineWidth', 1.5);

lgdd2 = legend([pd2], 'f(x)^{(II)}');
lgdd2.FontSize = 8;
hold off;                                                   %Do ovdje bi sve trebalo biti jasno od zadnjeg komentara, ako imate pitanja u vezi prethodnih linija, posaljite poruku na f2n hitno!

MaxMin = vpa(solve(d1f == 0, x));                           %Racunamo ekstreme tako da rjesavamo polinom nase 1. derivacije (ona govori o nagibu pravca itd. itd.)
yMaxMin = vpa(subs(f, x, MaxMin));                          %Ovo je samo matrica sa y vrijednostima za izracunate x koordinate ekstrema.

subplot(2, 1, 1)                                            %Vratili smo se na nas "prevarantski" subplot.
hold on;
p4 = plot(MaxMin(1), yMaxMin(1), 'ob');                     %Minimum i maksimum cu drugacije obojati, pa ih trebam i odvojeno instancirati
p5 = plot(MaxMin(2), yMaxMin(2), 'og');

lgd = legend([p1 p2 p4 p5], 'f(x)', 'nultocke', 'globalni minimum', 'globalni maksimum');   %Legendu tek tu inicijaliziram jer smo tek sad gotovi sa kreacijom prvog grafa
lgd.FontSize = 8;
hold off;

%-------------e) zadatak---------------------------------------------------

uiwait(msgbox(sprintf('Povrsina ispod f(x) u intervalu od -1 do 1 je priblizno %f kvadratnih jedinica', int(f, x, -1, 1)), 'Povrsina')); %int ce integrirati f po x-u u rasponu od -1 do 1.