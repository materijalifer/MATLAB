%Autor: Ljac
%2.037s

clc

tirkizna = [0.251, 0.878, 0.816];
syms Us Rs Cs Ls t;                                                         %Nazivam ih Us itd. jer U, R, C i L su zauzeti od Z2, tj. callbacka Z2.

%Ponovno cemo definirati jednadzbu iz 1. zadatka da ne ovisimo o
%inicijaliziranoj varijabli.

Uc = 'D2Uc = (Us-Uc)/(Ls*Cs) - DUc/(Rs*Cs)';                                %Pojednostavio sam formulu, usprkos drukcijem izgledu ona je ekvivalentna onoj u Z1
Uc = simplify(dsolve(Uc, 'Uc(0) = 5', 'DUc(0) = 0'));                       %Prvo rjesavamo jednad�bu, onda cemo uvrstiti brojke.

Uc = subs(Uc, [Us, Rs, Cs, Ls], [U, R, C, L]);                              %Mijenjamo vrijednosti Uc-a sa vrijednostima iz Z2.
Uc_stv = subs(Uc, t, vrijeme);                                              %vrijeme je nas clock iz Z2, stavljamo ga na mjesto t-a u jednadzbi

Erel = (Uc_sim - Uc_stv)./Uc_stv;                                           %Umjesto Y ja pisem Uc. Y je os a ne vrijednost koju racunamo, pa je Uc tocniji izraz. Djelim po elementima, jer ipak su nase vrijednosti vektori.

%Graf----------------------------------------------------------------------

figure
hold on
grid on

p1 = plot(vrijeme, Erel.*100, 'Color', tirkizna, 'LineWidth', sqrt(3));     %Zelim postotke pa Erel mnozim s 100.
lgd = legend(p1, '\Delta_r simulacije');                                    %Ako stavimo \ i onda engleski naziv grckog slova, ono se ispisuje normalno. Ako pocne velikim slovom, onda je veliko slovo, ako pocne malim slovom, onda je malo slovo.
lgd.FontSize = 8;

xlabel('t / s');
ylabel('\Delta_r / %');
title('Relativna pogreska simulacije');
hold off;