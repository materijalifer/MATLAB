%Autor: Ljac
%Jednadzbe sa F2N, ne znam tko je original napisao, ali dajem credit Tyrannizeru
%0.780s

clc

tirkizna = [0.251, 0.878, 0.816];                   %Definiram RGB matricu boje, opcionalno.
U_R_C_L = sym([10, 20, 10e-5, 10e-3]);              %Redom U, R, C i L u voltima, ohmima, faradima i henrijima. Ovo se mo�e mijenjati kasnije.

syms U R C L                                        %Redom simbolicke varijable U, R, C, L. Takodjer postoji i t, ali on nam nije potreban za sad :)
    
%Simbolicke jednadzbe napona i naboja na kondenzatoru, neka elektrotehnicka
%magija, iskreno za izvod nemam pojma, a na internetu osim rjesenja
%postupak ne mogu naci. Ako netko zna, neka javi.

Uc = 'D2Uc == U/(L*C) - Uc/(L*C)- DUc/(R*C)';       %Definirali smo Uc kao string simbolicke diferencijalne jednadzbe. D ispred varijable znaci prva derivacija (diff() ne radi), a Dn, gdje je n neki prirodni broj je n-ta derivacija tog izraza.
fprintf('\nRjesenje jednadzbe za napon na kondenzatoru je\n\n');
pretty(dsolve(Uc))                                  %MATLAB po defaultu uzima da je t varijabla po kojoj deriviramo - da smo imali nesto kao DUc/dx, nasa naredba bi bila dsolve(Uc, 'x').

Qc = 'D2Qc == U/L - Qc/(L*C) - DQc/(R*C)';          %Isti princip kao i prethodna formula.
fprintf('\nRjesenje jednadzbe za naboj na kondenzatoru je\n\n');
pretty(dsolve(Qc))                                   %Varijabla po kojoj deriviramo je opet t.

Uc_1 = simplify(dsolve(Uc, 'Uc(0)=5', 'DUc(0)=0')); %Sada rjesavamo Uc na nacin da nam je pocetni napon 5 (dakle, Uc(0) = 5), te da je u pocetnom trenutku krug u stacionarnom stanju (promjena napona na kondenzatoru u tom trenutku ne postoji).
Uc_1 = subs(Uc_1, [U, R, C, L], U_R_C_L);           %Mijenjamo U, R, C i L sa postavljenim defaultim vrijednostima.

%Preostalo je samo iscrtati graf Uc_1--------------------------------------

figure
hold on
grid on

%Sljedece dvije linije mogu se zamijeniti sa "p1 = ezplot(Uc_1, [0 0.04])". Ja ne koristim ezplot jer je depreciran i ne mogu kontrolirati boje.
p1 = fplot(Uc_1, [0 0.04], 'Color', tirkizna, 'LineWidth', sqrt(3));
xlim([0 0.04]);                                     %Domena iscrtavanja (iscrtava samo do tud iako je prava domena mozda i veca)
ylim([4 14]);                                       %Slika iscrtavanja
lgd = legend(p1, 'U_{kondenzatora}');
lgd.FontSize = 8;

xlabel('t / s');
ylabel('Uc / V');
title('Napon kondenzatora kroz vrijeme');
hold off;